
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ChatLayout from '@/layouts/ChatLayout';
import { UserProvider } from '@/contexts/UserContext';
import { ChatProvider } from '@/contexts/ChatContext';

function App() {
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  
  useEffect(() => {
    // Simulate initial loading
    const timer = setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Bem-vindo ao ChatApp",
        description: "Aplicativo de mensagens com funcionalidades do Discord e WhatsApp",
        duration: 5000,
      });
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [toast]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen w-screen bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          <h1 className="text-2xl font-bold text-primary">Carregando...</h1>
        </div>
      </div>
    );
  }

  return (
    <ThemeProvider defaultTheme="dark" storageKey="chat-theme">
      <UserProvider>
        <ChatProvider>
          <Router>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/chat/*" element={<ChatLayout />} />
              <Route path="*" element={<Navigate to="/login" replace />} />
            </Routes>
          </Router>
          <Toaster />
        </ChatProvider>
      </UserProvider>
    </ThemeProvider>
  );
}

export default App;
