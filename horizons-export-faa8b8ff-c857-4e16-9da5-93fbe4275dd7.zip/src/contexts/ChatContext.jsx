
import React, { createContext, useContext, useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { format } from 'date-fns';
import { useUser } from '@/contexts/UserContext';
import { useToast } from '@/components/ui/use-toast';

const ChatContext = createContext();

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};

export const ChatProvider = ({ children }) => {
  const { currentUser } = useUser();
  const { toast } = useToast();
  
  const [channels, setChannels] = useState([]);
  const [directMessages, setDirectMessages] = useState([]);
  const [activeChannel, setActiveChannel] = useState(null);
  const [activeDM, setActiveDM] = useState(null);
  const [messages, setMessages] = useState([]);
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize demo data if not exists
  useEffect(() => {
    if (!currentUser) return;

    const initializeData = () => {
      // Load users
      const savedUsers = JSON.parse(localStorage.getItem('users') || '[]');
      setUsers(savedUsers);

      // Load or initialize channels
      let savedChannels = JSON.parse(localStorage.getItem('channels') || '[]');
      if (savedChannels.length === 0) {
        savedChannels = [
          {
            id: 'general',
            name: 'Geral',
            description: 'Canal para conversas gerais',
            createdBy: 'system',
            createdAt: new Date().toISOString(),
            isPublic: true,
            members: savedUsers.map(u => u.id),
          },
          {
            id: 'random',
            name: 'Aleatório',
            description: 'Canal para conversas aleatórias',
            createdBy: 'system',
            createdAt: new Date().toISOString(),
            isPublic: true,
            members: savedUsers.map(u => u.id),
          },
        ];
        localStorage.setItem('channels', JSON.stringify(savedChannels));
      }
      setChannels(savedChannels);

      // Load or initialize direct messages
      const savedDMs = JSON.parse(localStorage.getItem('directMessages') || '[]');
      setDirectMessages(savedDMs);

      // Load messages
      const savedMessages = JSON.parse(localStorage.getItem('messages') || '[]');
      setMessages(savedMessages);

      // Set default active channel
      if (savedChannels.length > 0 && !activeChannel) {
        setActiveChannel(savedChannels[0]);
      }

      setIsLoading(false);
    };

    initializeData();
  }, [currentUser]);

  const createChannel = (name, description, isPublic = true) => {
    if (!currentUser) return null;

    const newChannel = {
      id: uuidv4(),
      name,
      description,
      createdBy: currentUser.id,
      createdAt: new Date().toISOString(),
      isPublic,
      members: [currentUser.id],
    };

    const updatedChannels = [...channels, newChannel];
    setChannels(updatedChannels);
    localStorage.setItem('channels', JSON.stringify(updatedChannels));
    
    toast({
      title: "Canal criado",
      description: `O canal ${name} foi criado com sucesso`,
    });

    return newChannel;
  };

  const joinChannel = (channelId) => {
    if (!currentUser) return false;

    const updatedChannels = channels.map(channel => {
      if (channel.id === channelId && !channel.members.includes(currentUser.id)) {
        return {
          ...channel,
          members: [...channel.members, currentUser.id],
        };
      }
      return channel;
    });

    setChannels(updatedChannels);
    localStorage.setItem('channels', JSON.stringify(updatedChannels));
    
    const joinedChannel = updatedChannels.find(c => c.id === channelId);
    
    // Create system message
    const systemMessage = {
      id: uuidv4(),
      channelId,
      senderId: 'system',
      content: `${currentUser.name} entrou no canal`,
      timestamp: new Date().toISOString(),
      type: 'system',
    };
    
    const updatedMessages = [...messages, systemMessage];
    setMessages(updatedMessages);
    localStorage.setItem('messages', JSON.stringify(updatedMessages));
    
    toast({
      title: "Canal acessado",
      description: `Você entrou no canal ${joinedChannel.name}`,
    });
    
    return true;
  };

  const leaveChannel = (channelId) => {
    if (!currentUser) return false;

    const updatedChannels = channels.map(channel => {
      if (channel.id === channelId) {
        return {
          ...channel,
          members: channel.members.filter(id => id !== currentUser.id),
        };
      }
      return channel;
    });

    setChannels(updatedChannels);
    localStorage.setItem('channels', JSON.stringify(updatedChannels));
    
    // Create system message
    const systemMessage = {
      id: uuidv4(),
      channelId,
      senderId: 'system',
      content: `${currentUser.name} saiu do canal`,
      timestamp: new Date().toISOString(),
      type: 'system',
    };
    
    const updatedMessages = [...messages, systemMessage];
    setMessages(updatedMessages);
    localStorage.setItem('messages', JSON.stringify(updatedMessages));
    
    // If active channel is the one being left, set to null
    if (activeChannel && activeChannel.id === channelId) {
      setActiveChannel(null);
    }
    
    toast({
      title: "Canal abandonado",
      description: `Você saiu do canal`,
    });
    
    return true;
  };

  const startDirectMessage = (userId) => {
    if (!currentUser || userId === currentUser.id) return null;

    // Check if DM already exists
    const existingDM = directMessages.find(dm => 
      (dm.members[0] === currentUser.id && dm.members[1] === userId) ||
      (dm.members[0] === userId && dm.members[1] === currentUser.id)
    );

    if (existingDM) {
      setActiveDM(existingDM);
      return existingDM;
    }

    // Create new DM
    const newDM = {
      id: uuidv4(),
      members: [currentUser.id, userId],
      createdAt: new Date().toISOString(),
    };

    const updatedDMs = [...directMessages, newDM];
    setDirectMessages(updatedDMs);
    localStorage.setItem('directMessages', JSON.stringify(updatedDMs));
    
    setActiveDM(newDM);
    
    const targetUser = users.find(u => u.id === userId);
    if (targetUser) {
      toast({
        title: "Conversa iniciada",
        description: `Conversa com ${targetUser.name} iniciada`,
      });
    }
    
    return newDM;
  };

  const sendMessage = (content, channelId = null, dmId = null, type = 'text') => {
    if (!currentUser) return null;
    if (!channelId && !dmId) return null;

    const newMessage = {
      id: uuidv4(),
      channelId,
      dmId,
      senderId: currentUser.id,
      content,
      timestamp: new Date().toISOString(),
      type,
      status: 'sent',
    };

    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages);
    localStorage.setItem('messages', JSON.stringify(updatedMessages));

    return newMessage;
  };

  const deleteMessage = (messageId) => {
    if (!currentUser) return false;

    const messageToDelete = messages.find(m => m.id === messageId);
    if (!messageToDelete || messageToDelete.senderId !== currentUser.id) {
      return false;
    }

    const updatedMessages = messages.filter(m => m.id !== messageId);
    setMessages(updatedMessages);
    localStorage.setItem('messages', JSON.stringify(updatedMessages));
    
    toast({
      title: "Mensagem excluída",
      description: "A mensagem foi excluída com sucesso",
    });
    
    return true;
  };

  const editMessage = (messageId, newContent) => {
    if (!currentUser) return false;

    const messageToEdit = messages.find(m => m.id === messageId);
    if (!messageToEdit || messageToEdit.senderId !== currentUser.id) {
      return false;
    }

    const updatedMessages = messages.map(m => {
      if (m.id === messageId) {
        return {
          ...m,
          content: newContent,
          edited: true,
          editedAt: new Date().toISOString(),
        };
      }
      return m;
    });

    setMessages(updatedMessages);
    localStorage.setItem('messages', JSON.stringify(updatedMessages));
    
    toast({
      title: "Mensagem editada",
      description: "A mensagem foi editada com sucesso",
    });
    
    return true;
  };

  const getChannelMessages = (channelId) => {
    return messages.filter(m => m.channelId === channelId);
  };

  const getDirectMessages = (dmId) => {
    return messages.filter(m => m.dmId === dmId);
  };

  const getUserById = (userId) => {
    if (userId === 'system') {
      return {
        id: 'system',
        name: 'Sistema',
        avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=system',
      };
    }
    return users.find(u => u.id === userId);
  };

  const formatMessageTime = (timestamp) => {
    return format(new Date(timestamp), 'HH:mm');
  };

  const value = {
    channels,
    directMessages,
    activeChannel,
    setActiveChannel,
    activeDM,
    setActiveDM,
    messages,
    users,
    isLoading,
    createChannel,
    joinChannel,
    leaveChannel,
    startDirectMessage,
    sendMessage,
    deleteMessage,
    editMessage,
    getChannelMessages,
    getDirectMessages,
    getUserById,
    formatMessageTime,
  };

  return (
    <ChatContext.Provider value={value}>
      {children}
    </ChatContext.Provider>
  );
};
