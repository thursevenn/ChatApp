
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useUser } from '@/contexts/UserContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { useToast } from '@/components/ui/use-toast';
import { 
  Menu, 
  User, 
  Shield, 
  Bell, 
  Palette, 
  Save, 
  ArrowLeft
} from 'lucide-react';

const UserSettings = ({ toggleSidebar }) => {
  const { currentUser, updateProfile, logout } = useUser();
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const [name, setName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [avatar, setAvatar] = useState(currentUser?.avatar || '');
  const [isLoading, setIsLoading] = useState(false);
  
  const handleSaveProfile = () => {
    setIsLoading(true);
    
    try {
      if (!name.trim()) {
        toast({
          title: "Nome obrigatório",
          description: "Por favor, insira seu nome",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }
      
      updateProfile({
        name,
        email,
        avatar,
      });
      
      toast({
        title: "Perfil atualizado",
        description: "Suas informações foram atualizadas com sucesso",
      });
    } catch (error) {
      toast({
        title: "Erro ao atualizar perfil",
        description: error.message || "Ocorreu um erro ao atualizar seu perfil",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  const handleBack = () => {
    navigate(-1);
  };
  
  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="px-4 py-3 border-b border-border flex items-center justify-between">
        <div className="flex items-center">
          <Button variant="ghost" size="icon" className="md:hidden mr-2" onClick={toggleSidebar}>
            <Menu className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="mr-2" onClick={handleBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h2 className="font-semibold">Configurações</h2>
        </div>
      </div>
      
      {/* Settings content */}
      <div className="flex-1 overflow-auto p-4">
        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="profile" className="flex items-center">
              <User className="h-4 w-4 mr-2" />
              Perfil
            </TabsTrigger>
            <TabsTrigger value="account" className="flex items-center">
              <Shield className="h-4 w-4 mr-2" />
              Conta
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center">
              <Bell className="h-4 w-4 mr-2" />
              Notificações
            </TabsTrigger>
            <TabsTrigger value="appearance" className="flex items-center">
              <Palette className="h-4 w-4 mr-2" />
              Aparência
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="profile" className="space-y-6">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="md:w-1/3">
                <div className="flex flex-col items-center space-y-4 p-6 bg-card rounded-lg border border-border">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src={avatar} alt={name} />
                    <AvatarFallback>{name?.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <h3 className="font-semibold text-lg">{name}</h3>
                  <p className="text-sm text-muted-foreground">{email}</p>
                  <Button variant="outline" className="w-full">
                    Alterar avatar
                  </Button>
                </div>
              </div>
              
              <div className="md:w-2/3 space-y-6">
                <div className="space-y-4 p-6 bg-card rounded-lg border border-border">
                  <h3 className="font-semibold text-lg">Informações do perfil</h3>
                  
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome</Label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Seu nome"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="seu@email.com"
                      disabled
                    />
                    <p className="text-xs text-muted-foreground">O email não pode ser alterado</p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="avatar">URL do Avatar</Label>
                    <Input
                      id="avatar"
                      value={avatar}
                      onChange={(e) => setAvatar(e.target.value)}
                      placeholder="https://exemplo.com/avatar.png"
                    />
                  </div>
                  
                  <div className="flex justify-end">
                    <Button onClick={handleSaveProfile} disabled={isLoading}>
                      {isLoading ? (
                        <div className="flex items-center">
                          <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2"></div>
                          Salvando...
                        </div>
                      ) : (
                        <>
                          <Save className="h-4 w-4 mr-2" />
                          Salvar alterações
                        </>
                      )}
                    </Button>
                  </div>
                </div>
                
                <div className="p-6 bg-card rounded-lg border border-border">
                  <h3 className="font-semibold text-lg mb-4">Status</h3>
                  
                  <div className="flex space-x-2">
                    <Button variant="outline" className="flex-1">Online</Button>
                    <Button variant="outline" className="flex-1">Ausente</Button>
                    <Button variant="outline" className="flex-1">Não perturbe</Button>
                    <Button variant="outline" className="flex-1">Invisível</Button>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-6 bg-destructive/10 rounded-lg border border-destructive/20">
              <h3 className="font-semibold text-lg mb-4 text-destructive">Zona de perigo</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Estas ações são irreversíveis. Tenha cuidado ao utilizá-las.
              </p>
              <div className="flex space-x-4">
                <Button variant="destructive" onClick={handleLogout}>
                  Sair da conta
                </Button>
                <Button variant="outline" className="text-destructive border-destructive">
                  Excluir conta
                </Button>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="account">
            <div className="p-6 bg-card rounded-lg border border-border">
              <h3 className="font-semibold text-lg mb-4">Segurança da conta</h3>
              <p className="text-muted-foreground">
                Configurações de segurança da sua conta serão implementadas em breve.
              </p>
            </div>
          </TabsContent>
          
          <TabsContent value="notifications">
            <div className="p-6 bg-card rounded-lg border border-border">
              <h3 className="font-semibold text-lg mb-4">Preferências de notificação</h3>
              <p className="text-muted-foreground">
                Configurações de notificação serão implementadas em breve.
              </p>
            </div>
          </TabsContent>
          
          <TabsContent value="appearance">
            <div className="p-6 bg-card rounded-lg border border-border">
              <h3 className="font-semibold text-lg mb-4">Tema e aparência</h3>
              <p className="text-muted-foreground">
                Configurações de aparência serão implementadas em breve.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default UserSettings;
