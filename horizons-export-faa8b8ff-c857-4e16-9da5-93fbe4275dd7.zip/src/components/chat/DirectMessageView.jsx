
import React, { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useChat } from '@/contexts/ChatContext';
import { useUser } from '@/contexts/UserContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import { Separator } from '@/components/ui/separator';
import { 
  Menu, 
  Send, 
  Smile, 
  Paperclip, 
  Phone, 
  Video,
  Info
} from 'lucide-react';
import EmojiPicker from 'emoji-picker-react';
import MessageItem from '@/components/chat/MessageItem';

const DirectMessageView = ({ toggleSidebar }) => {
  const { dmId } = useParams();
  const { 
    directMessages, 
    getDirectMessages, 
    sendMessage, 
    getUserById 
  } = useChat();
  const { currentUser } = useUser();
  
  const [messageText, setMessageText] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  
  const dm = directMessages.find(d => d.id === dmId);
  const messages = getDirectMessages(dmId);
  
  // Get the other user in the DM
  const otherUserId = dm?.members.find(id => id !== currentUser?.id);
  const otherUser = getUserById(otherUserId);
  
  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  const handleSendMessage = (e) => {
    e.preventDefault();
    
    if (!messageText.trim()) return;
    
    sendMessage(messageText, null, dmId);
    setMessageText('');
    setShowEmojiPicker(false);
  };
  
  const handleEmojiClick = (emojiData) => {
    setMessageText(prev => prev + emojiData.emoji);
    inputRef.current?.focus();
  };
  
  // Group messages by date
  const groupedMessages = messages.reduce((groups, message) => {
    const date = new Date(message.timestamp).toLocaleDateString();
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(message);
    return groups;
  }, {});
  
  if (!dm || !otherUser) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Conversa não encontrada</h2>
          <p className="text-muted-foreground">A conversa que você está procurando não existe.</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="h-full flex flex-col">
      {/* DM header */}
      <div className="px-4 py-3 border-b border-border flex items-center justify-between">
        <div className="flex items-center">
          <Button variant="ghost" size="icon" className="md:hidden mr-2" onClick={toggleSidebar}>
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex items-center">
            <Avatar className="h-8 w-8 mr-2">
              <AvatarImage src={otherUser.avatar} alt={otherUser.name} />
              <AvatarFallback>{otherUser.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <h2 className="font-semibold">{otherUser.name}</h2>
              <p className="text-xs text-muted-foreground">Online</p>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="icon">
            <Phone className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <Video className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <Info className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Messages area */}
      <ScrollArea className="flex-1 p-4">
        {Object.keys(groupedMessages).length > 0 ? (
          <div className="space-y-6">
            {Object.entries(groupedMessages).map(([date, dateMessages]) => (
              <div key={date}>
                <div className="flex items-center mb-4">
                  <Separator className="flex-grow" />
                  <span className="px-2 text-xs text-muted-foreground">{date}</span>
                  <Separator className="flex-grow" />
                </div>
                
                <div className="space-y-4">
                  {dateMessages.map(message => (
                    <MessageItem 
                      key={message.id} 
                      message={message} 
                      currentUser={currentUser}
                      isDM={true}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="h-full flex items-center justify-center">
            <div className="text-center max-w-md">
              <Avatar className="h-16 w-16 mx-auto mb-4">
                <AvatarImage src={otherUser.avatar} alt={otherUser.name} />
                <AvatarFallback>{otherUser.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <h3 className="text-xl font-semibold mb-2">Conversa com {otherUser.name}</h3>
              <p className="text-muted-foreground mb-4">
                Esta é uma nova conversa. Envie uma mensagem para começar a conversar.
              </p>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </ScrollArea>
      
      {/* Message input */}
      <div className="p-4 border-t border-border">
        <form onSubmit={handleSendMessage} className="flex items-end space-x-2">
          <div className="relative flex-1">
            <Input
              ref={inputRef}
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder={`Mensagem para ${otherUser.name}`}
              className="pr-20 min-h-[44px] py-3"
            />
            <div className="absolute right-2 bottom-1.5 flex space-x-1">
              <Popover open={showEmojiPicker} onOpenChange={setShowEmojiPicker}>
                <PopoverTrigger asChild>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 rounded-full"
                  >
                    <Smile className="h-5 w-5 text-muted-foreground" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0 border-none" align="end">
                  <div className="emoji-picker-container">
                    <EmojiPicker 
                      onEmojiClick={handleEmojiClick} 
                      width={300} 
                      height={400}
                    />
                  </div>
                </PopoverContent>
              </Popover>
              
              <Button 
                type="button" 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 rounded-full"
              >
                <Paperclip className="h-5 w-5 text-muted-foreground" />
              </Button>
            </div>
          </div>
          
          <Button 
            type="submit" 
            size="icon" 
            className="h-[44px] w-[44px]"
            disabled={!messageText.trim()}
          >
            <Send className="h-5 w-5" />
          </Button>
        </form>
      </div>
    </div>
  );
};

export default DirectMessageView;
