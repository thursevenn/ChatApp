
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useChat } from '@/contexts/ChatContext';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { 
  MoreVertical, 
  Edit, 
  Trash, 
  Reply, 
  Copy, 
  Check
} from 'lucide-react';

const MessageItem = ({ message, currentUser, isDM = false }) => {
  const { getUserById, formatMessageTime, deleteMessage, editMessage } = useChat();
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState(message.content);
  const [showActions, setShowActions] = useState(false);
  
  const sender = getUserById(message.senderId);
  const isCurrentUserMessage = message.senderId === currentUser?.id;
  const isSystemMessage = message.type === 'system';
  
  const handleEdit = () => {
    setIsEditing(true);
    setEditedContent(message.content);
  };
  
  const handleSaveEdit = () => {
    if (editedContent.trim() && editedContent !== message.content) {
      editMessage(message.id, editedContent);
    }
    setIsEditing(false);
  };
  
  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedContent(message.content);
  };
  
  const handleDelete = () => {
    deleteMessage(message.id);
  };
  
  const handleCopyMessage = () => {
    navigator.clipboard.writeText(message.content);
  };
  
  if (isSystemMessage) {
    return (
      <div className="flex justify-center my-2">
        <span className="text-xs text-muted-foreground bg-muted/50 px-2 py-1 rounded-md">
          {message.content}
        </span>
      </div>
    );
  }
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`group message-hover rounded-md px-2 py-1 ${isDM && isCurrentUserMessage ? 'bg-primary/10' : ''}`}
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
    >
      <div className="flex">
        <Avatar className="h-10 w-10 mr-3 mt-1 flex-shrink-0">
          <AvatarImage src={sender?.avatar} alt={sender?.name} />
          <AvatarFallback>{sender?.name?.charAt(0)}</AvatarFallback>
        </Avatar>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center">
            <span className="font-semibold text-sm">{sender?.name}</span>
            <span className="text-xs text-muted-foreground ml-2">
              {formatMessageTime(message.timestamp)}
            </span>
            {message.edited && (
              <span className="text-xs text-muted-foreground ml-2">(editado)</span>
            )}
          </div>
          
          {isEditing ? (
            <div className="mt-1 space-y-2">
              <Input
                value={editedContent}
                onChange={(e) => setEditedContent(e.target.value)}
                autoFocus
                className="bg-background/50"
              />
              <div className="flex space-x-2">
                <Button size="sm" onClick={handleSaveEdit}>
                  <Check className="h-4 w-4 mr-1" />
                  Salvar
                </Button>
                <Button size="sm" variant="outline" onClick={handleCancelEdit}>
                  Cancelar
                </Button>
              </div>
            </div>
          ) : (
            <p className="text-sm mt-1 break-words">{message.content}</p>
          )}
        </div>
        
        {showActions && !isEditing && (
          <div className="flex items-start ml-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 opacity-70">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => {}}>
                  <Reply className="h-4 w-4 mr-2" />
                  Responder
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleCopyMessage}>
                  <Copy className="h-4 w-4 mr-2" />
                  Copiar texto
                </DropdownMenuItem>
                
                {isCurrentUserMessage && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleEdit}>
                      <Edit className="h-4 w-4 mr-2" />
                      Editar
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={handleDelete}
                      className="text-destructive focus:text-destructive"
                    >
                      <Trash className="h-4 w-4 mr-2" />
                      Excluir
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default MessageItem;
