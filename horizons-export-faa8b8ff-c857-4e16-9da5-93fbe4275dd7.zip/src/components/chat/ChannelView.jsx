
import React, { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useChat } from '@/contexts/ChatContext';
import { useUser } from '@/contexts/UserContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider } from '@/components/ui/tooltip';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/components/ui/use-toast';
import { 
  Menu, 
  Hash, 
  Users, 
  Info, 
  Send, 
  Smile, 
  Paperclip, 
  MoreVertical, 
  Edit, 
  Trash, 
  Reply, 
  UserPlus,
  LogOut
} from 'lucide-react';
import EmojiPicker from 'emoji-picker-react';
import MessageItem from '@/components/chat/MessageItem';

const ChannelView = ({ toggleSidebar }) => {
  const { channelId } = useParams();
  const { 
    channels, 
    getChannelMessages, 
    sendMessage, 
    getUserById, 
    joinChannel, 
    leaveChannel 
  } = useChat();
  const { currentUser } = useUser();
  const { toast } = useToast();
  
  const [messageText, setMessageText] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showChannelInfo, setShowChannelInfo] = useState(false);
  const [isJoined, setIsJoined] = useState(false);
  
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  
  const channel = channels.find(c => c.id === channelId);
  const messages = getChannelMessages(channelId);
  
  // Check if user is a member of the channel
  useEffect(() => {
    if (channel && currentUser) {
      setIsJoined(channel.members.includes(currentUser.id));
    }
  }, [channel, currentUser]);
  
  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  const handleSendMessage = (e) => {
    e.preventDefault();
    
    if (!messageText.trim()) return;
    if (!isJoined) {
      toast({
        title: "Não é possível enviar mensagem",
        description: "Você precisa entrar no canal primeiro",
        variant: "destructive",
      });
      return;
    }
    
    sendMessage(messageText, channelId);
    setMessageText('');
    setShowEmojiPicker(false);
  };
  
  const handleEmojiClick = (emojiData) => {
    setMessageText(prev => prev + emojiData.emoji);
    inputRef.current?.focus();
  };
  
  const handleJoinChannel = () => {
    joinChannel(channelId);
    setIsJoined(true);
  };
  
  const handleLeaveChannel = () => {
    leaveChannel(channelId);
    setIsJoined(false);
  };
  
  // Group messages by date
  const groupedMessages = messages.reduce((groups, message) => {
    const date = new Date(message.timestamp).toLocaleDateString();
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(message);
    return groups;
  }, {});
  
  if (!channel) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Canal não encontrado</h2>
          <p className="text-muted-foreground">O canal que você está procurando não existe.</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="h-full flex flex-col">
      {/* Channel header */}
      <div className="px-4 py-3 border-b border-border flex items-center justify-between">
        <div className="flex items-center">
          <Button variant="ghost" size="icon" className="md:hidden mr-2" onClick={toggleSidebar}>
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex items-center">
            <Hash className="h-5 w-5 mr-2 text-muted-foreground" />
            <h2 className="font-semibold">{channel.name}</h2>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => setShowChannelInfo(!showChannelInfo)}
                >
                  <Info className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Informações do canal</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Users className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Membros do canal</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          {isJoined ? (
            <Button 
              variant="outline" 
              size="sm" 
              className="text-xs"
              onClick={handleLeaveChannel}
            >
              <LogOut className="h-3.5 w-3.5 mr-1" />
              Sair
            </Button>
          ) : (
            <Button 
              variant="default" 
              size="sm" 
              className="text-xs"
              onClick={handleJoinChannel}
            >
              <UserPlus className="h-3.5 w-3.5 mr-1" />
              Entrar
            </Button>
          )}
        </div>
      </div>
      
      {/* Channel info sidebar */}
      <AnimatePresence>
        {showChannelInfo && (
          <motion.div
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 300, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute right-0 top-0 h-full bg-card border-l border-border z-10 overflow-hidden"
          >
            <div className="p-4 h-full flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Informações do Canal</h3>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => setShowChannelInfo(false)}
                >
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Nome</h4>
                  <p className="text-sm">{channel.name}</p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Descrição</h4>
                  <p className="text-sm">{channel.description || "Sem descrição"}</p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Criado em</h4>
                  <p className="text-sm">{new Date(channel.createdAt).toLocaleDateString()}</p>
                </div>
                
                <Separator />
                
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Membros ({channel.members.length})</h4>
                  <ScrollArea className="h-[200px] pr-4">
                    <div className="space-y-2">
                      {channel.members.map(memberId => {
                        const member = getUserById(memberId);
                        if (!member) return null;
                        
                        return (
                          <div key={memberId} className="flex items-center space-x-2">
                            <Avatar className="h-6 w-6">
                              <AvatarImage src={member.avatar} alt={member.name} />
                              <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <span className="text-sm">{member.name}</span>
                          </div>
                        );
                      })}
                    </div>
                  </ScrollArea>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Messages area */}
      <ScrollArea className="flex-1 p-4">
        {Object.keys(groupedMessages).length > 0 ? (
          <div className="space-y-6">
            {Object.entries(groupedMessages).map(([date, dateMessages]) => (
              <div key={date}>
                <div className="flex items-center mb-4">
                  <Separator className="flex-grow" />
                  <span className="px-2 text-xs text-muted-foreground">{date}</span>
                  <Separator className="flex-grow" />
                </div>
                
                <div className="space-y-4">
                  {dateMessages.map(message => (
                    <MessageItem 
                      key={message.id} 
                      message={message} 
                      currentUser={currentUser}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="h-full flex items-center justify-center">
            <div className="text-center max-w-md">
              <Hash className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
              <h3 className="text-xl font-semibold mb-2">Bem-vindo ao #{channel.name}</h3>
              <p className="text-muted-foreground mb-4">{channel.description || "Este é o início do canal."}</p>
              {!isJoined && (
                <Button onClick={handleJoinChannel}>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Entrar no canal
                </Button>
              )}
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </ScrollArea>
      
      {/* Message input */}
      <div className="p-4 border-t border-border">
        <form onSubmit={handleSendMessage} className="flex items-end space-x-2">
          <div className="relative flex-1">
            <Input
              ref={inputRef}
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder={isJoined ? `Mensagem para #${channel.name}` : "Entre no canal para enviar mensagens"}
              className="pr-20 min-h-[44px] py-3"
              disabled={!isJoined}
            />
            <div className="absolute right-2 bottom-1.5 flex space-x-1">
              <Popover open={showEmojiPicker} onOpenChange={setShowEmojiPicker}>
                <PopoverTrigger asChild>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 rounded-full"
                    disabled={!isJoined}
                  >
                    <Smile className="h-5 w-5 text-muted-foreground" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0 border-none" align="end">
                  <div className="emoji-picker-container">
                    <EmojiPicker 
                      onEmojiClick={handleEmojiClick} 
                      width={300} 
                      height={400}
                    />
                  </div>
                </PopoverContent>
              </Popover>
              
              <Button 
                type="button" 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 rounded-full"
                disabled={!isJoined}
              >
                <Paperclip className="h-5 w-5 text-muted-foreground" />
              </Button>
            </div>
          </div>
          
          <Button 
            type="submit" 
            size="icon" 
            className="h-[44px] w-[44px]"
            disabled={!messageText.trim() || !isJoined}
          >
            <Send className="h-5 w-5" />
          </Button>
        </form>
      </div>
    </div>
  );
};

export default ChannelView;
