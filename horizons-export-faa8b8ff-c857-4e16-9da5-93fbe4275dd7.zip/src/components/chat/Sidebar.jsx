
import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useUser } from '@/contexts/UserContext';
import { useChat } from '@/contexts/ChatContext';
import { useTheme } from '@/components/theme-provider';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  MessageSquare, 
  Users, 
  Plus, 
  Settings, 
  LogOut, 
  Moon, 
  Sun, 
  Hash, 
  ChevronDown, 
  ChevronRight,
  Lock
} from 'lucide-react';
import { cn } from '@/lib/utils';

const Sidebar = ({ onCloseMobile }) => {
  const { currentUser, logout } = useUser();
  const { channels, directMessages, users, getUserById, createChannel, startDirectMessage } = useChat();
  const { theme, setTheme } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  
  const [isChannelsOpen, setIsChannelsOpen] = useState(true);
  const [isDmsOpen, setIsDmsOpen] = useState(true);
  const [newChannelName, setNewChannelName] = useState('');
  const [newChannelDescription, setNewChannelDescription] = useState('');
  const [isNewChannelDialogOpen, setIsNewChannelDialogOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  const handleCreateChannel = () => {
    if (newChannelName.trim()) {
      const newChannel = createChannel(newChannelName.trim(), newChannelDescription.trim());
      setNewChannelName('');
      setNewChannelDescription('');
      setIsNewChannelDialogOpen(false);
      navigate(`/chat/channel/${newChannel.id}`);
      onCloseMobile();
    }
  };

  const handleStartDM = (userId) => {
    const dm = startDirectMessage(userId);
    if (dm) {
      navigate(`/chat/dm/${dm.id}`);
      onCloseMobile();
    }
  };

  const isChannelActive = (channelId) => {
    return location.pathname === `/chat/channel/${channelId}`;
  };

  const isDMActive = (dmId) => {
    return location.pathname === `/chat/dm/${dmId}`;
  };

  // Filter out current user from DM list
  const otherUsers = users.filter(user => user.id !== currentUser?.id);

  // Get DM partners for each DM
  const dmPartners = directMessages.map(dm => {
    const partnerId = dm.members.find(id => id !== currentUser?.id);
    const partner = getUserById(partnerId);
    return {
      ...dm,
      partner
    };
  });

  return (
    <div className="h-full flex flex-col bg-secondary/50 border-r border-border">
      {/* Header */}
      <div className="p-4 border-b border-border flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <MessageSquare className="h-6 w-6 text-primary" />
          <h1 className="font-bold text-lg">ChatApp</h1>
        </div>
        <Button variant="ghost" size="icon" onClick={toggleTheme}>
          {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>
      </div>

      {/* Channels and DMs */}
      <ScrollArea className="flex-1">
        <div className="p-2">
          {/* Channels section */}
          <div className="mb-4">
            <div 
              className="flex items-center justify-between p-2 cursor-pointer hover:bg-muted/50 rounded-md"
              onClick={() => setIsChannelsOpen(!isChannelsOpen)}
            >
              <div className="flex items-center">
                {isChannelsOpen ? <ChevronDown className="h-4 w-4 mr-1" /> : <ChevronRight className="h-4 w-4 mr-1" />}
                <span className="font-semibold text-sm">CANAIS</span>
              </div>
              <Dialog open={isNewChannelDialogOpen} onOpenChange={setIsNewChannelDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-5 w-5">
                    <Plus className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Criar novo canal</DialogTitle>
                    <DialogDescription>
                      Crie um novo canal para conversar com outros usuários.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="channel-name">Nome do canal</Label>
                      <Input 
                        id="channel-name" 
                        value={newChannelName} 
                        onChange={(e) => setNewChannelName(e.target.value)} 
                        placeholder="ex: geral, jogos, música"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="channel-description">Descrição (opcional)</Label>
                      <Input 
                        id="channel-description" 
                        value={newChannelDescription} 
                        onChange={(e) => setNewChannelDescription(e.target.value)} 
                        placeholder="Descreva o propósito deste canal"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsNewChannelDialogOpen(false)}>Cancelar</Button>
                    <Button onClick={handleCreateChannel}>Criar canal</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
            
            {isChannelsOpen && (
              <div className="ml-2 space-y-1 mt-1">
                {channels.map(channel => (
                  <Link 
                    key={channel.id} 
                    to={`/chat/channel/${channel.id}`}
                    onClick={onCloseMobile}
                  >
                    <div 
                      className={cn(
                        "flex items-center px-2 py-1.5 rounded-md text-sm group hover:bg-muted/80 transition-colors",
                        isChannelActive(channel.id) && "bg-muted text-primary font-medium"
                      )}
                    >
                      <Hash className="h-4 w-4 mr-2 flex-shrink-0" />
                      <span className="truncate">{channel.name}</span>
                      {!channel.isPublic && <Lock className="h-3 w-3 ml-1 opacity-70" />}
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {/* Direct Messages section */}
          <div className="mb-4">
            <div 
              className="flex items-center justify-between p-2 cursor-pointer hover:bg-muted/50 rounded-md"
              onClick={() => setIsDmsOpen(!isDmsOpen)}
            >
              <div className="flex items-center">
                {isDmsOpen ? <ChevronDown className="h-4 w-4 mr-1" /> : <ChevronRight className="h-4 w-4 mr-1" />}
                <span className="font-semibold text-sm">MENSAGENS DIRETAS</span>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-5 w-5">
                    <Plus className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Nova mensagem direta</DialogTitle>
                    <DialogDescription>
                      Selecione um usuário para iniciar uma conversa.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="py-4">
                    <ScrollArea className="h-[300px] pr-4">
                      {otherUsers.length > 0 ? (
                        <div className="space-y-2">
                          {otherUsers.map(user => (
                            <div 
                              key={user.id}
                              className="flex items-center p-2 hover:bg-muted rounded-md cursor-pointer"
                              onClick={() => {
                                handleStartDM(user.id);
                              }}
                            >
                              <Avatar className="h-8 w-8 mr-2">
                                <AvatarImage src={user.avatar} alt={user.name} />
                                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="text-sm font-medium">{user.name}</p>
                                <p className="text-xs text-muted-foreground">{user.email}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-center text-muted-foreground">Nenhum usuário disponível</p>
                      )}
                    </ScrollArea>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            
            {isDmsOpen && (
              <div className="ml-2 space-y-1 mt-1">
                {dmPartners.map(dm => (
                  <Link 
                    key={dm.id} 
                    to={`/chat/dm/${dm.id}`}
                    onClick={onCloseMobile}
                  >
                    <div 
                      className={cn(
                        "flex items-center px-2 py-1.5 rounded-md text-sm group hover:bg-muted/80 transition-colors",
                        isDMActive(dm.id) && "bg-muted text-primary font-medium"
                      )}
                    >
                      <Avatar className="h-5 w-5 mr-2">
                        <AvatarImage src={dm.partner?.avatar} alt={dm.partner?.name} />
                        <AvatarFallback>{dm.partner?.name?.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span className="truncate">{dm.partner?.name}</span>
                      <div className={cn(
                        "h-2 w-2 rounded-full ml-auto",
                        dm.partner?.status === 'online' ? "bg-green-500" : "bg-gray-500"
                      )} />
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </ScrollArea>

      {/* User section */}
      <div className="p-3 border-t border-border bg-secondary/80">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Avatar>
              <AvatarImage src={currentUser?.avatar} alt={currentUser?.name} />
              <AvatarFallback>{currentUser?.name?.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-sm font-medium truncate max-w-[120px]">{currentUser?.name}</p>
              <p className="text-xs text-muted-foreground">Online</p>
            </div>
          </div>
          <div className="flex space-x-1">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => {
                navigate('/chat/settings');
                onCloseMobile();
              }}
            >
              <Settings className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={handleLogout}>
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
