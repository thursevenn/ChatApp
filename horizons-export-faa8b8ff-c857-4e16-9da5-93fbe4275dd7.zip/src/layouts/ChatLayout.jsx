
import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useUser } from '@/contexts/UserContext';
import { useChat } from '@/contexts/ChatContext';
import Sidebar from '@/components/chat/Sidebar';
import ChannelView from '@/components/chat/ChannelView';
import DirectMessageView from '@/components/chat/DirectMessageView';
import UserSettings from '@/components/chat/UserSettings';
import { useToast } from '@/components/ui/use-toast';

const ChatLayout = () => {
  const { currentUser, isLoading: userLoading } = useUser();
  const { isLoading: chatLoading } = useChat();
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    if (!userLoading && !currentUser) {
      toast({
        title: "Acesso negado",
        description: "Você precisa fazer login para acessar o chat",
        variant: "destructive",
      });
      navigate('/login');
    }
  }, [currentUser, userLoading, navigate, toast]);

  if (userLoading || chatLoading) {
    return (
      <div className="flex items-center justify-center h-screen w-screen bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          <h1 className="text-2xl font-bold text-primary">Carregando...</h1>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Mobile sidebar backdrop */}
      {isMobileSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-20 md:hidden"
          onClick={() => setIsMobileSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <motion.div
        initial={{ x: -300 }}
        animate={{ x: 0 }}
        transition={{ duration: 0.3 }}
        className={`fixed md:relative z-30 md:z-auto h-full ${
          isMobileSidebarOpen ? 'left-0' : '-left-full'
        } md:left-0 transition-all duration-300 w-64 flex-shrink-0`}
      >
        <Sidebar onCloseMobile={() => setIsMobileSidebarOpen(false)} />
      </motion.div>

      {/* Main content */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3, delay: 0.2 }}
        className="flex-1 flex flex-col h-full overflow-hidden"
      >
        <Routes>
          <Route path="/channel/:channelId" element={<ChannelView toggleSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)} />} />
          <Route path="/dm/:dmId" element={<DirectMessageView toggleSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)} />} />
          <Route path="/settings" element={<UserSettings toggleSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)} />} />
          <Route path="*" element={<Navigate to="/chat/channel/general" replace />} />
        </Routes>
      </motion.div>
    </div>
  );
};

export default ChatLayout;
